Ray Valenzuela

Round-Robin Scheduler Implementation
=====================================

AUTHOR: Ray Valenzuela

OVERVIEW:
This is a user-level implementation of a round-robin process scheduler. It forks multiple
child processes and allows each to run for a specified quantum (time slice) before stopping
and switching to the next process.

FILES:
- schedule.c: Main scheduler implementation
- schedule.h: Header file with process structure and constants
- two.c: Test program that prints a number repeatedly
- Makefile: Build configuration
- README.txt: This file

BUILDING:
Run: make

This will compile both the scheduler and the test program.

SUBMISSION NOTE:
Run `make clean` before creating schedule.tar.gz so no binaries are included.

USAGE:
./schedule quantum prog1 [args] : prog2 [args] : prog3 [args] : ...

Example:
./schedule 1000 ./two 3 : ./two 2 : ./two 1

PARAMETERS:
- quantum: Time slice in milliseconds that each process gets per turn
- prog1, prog2, etc.: Program executables to schedule
- args: Arguments to pass to each program
- Colons (: ) with spaces before and after separate different programs

IMPLEMENTATION DETAILS:

1. PROCESS CREATION:
   - All child processes are forked and immediately sent SIGSTOP so they don't run until scheduled

2. SCHEDULING:
   - Processes take turns in the order they were specified on the command line
   - Each process receives up to 'quantum' milliseconds of CPU time
   - If a process finishes before using its full quantum, it exits immediately
   - If a process suspends itself, it continues on the next round
   - Dead processes are removed from the rotation

3. SIGNAL HANDLING:
   - SIGALRM: Fires when the quantum expires
   - SIGCHLD: Fires when a child process changes state (exits or stops)
   - The scheduler uses these signals to know when to switch processes

4. CONSTANTS:
   - MAX_PROCESSES: 150 (can support up to this many concurrent processes)
   - MAX_ARGUMENTS: 10 (each process can have up to this many command-line arguments)

TESTING:
The scheduler comes with a test program called "two" which:
- Takes one argument: a number N
- Prints that number N times with a 1-second delay between prints
- Uses a field width of 8*N for formatting

Example test runs:

Test 1: Process has enough time to complete
  ./schedule 10000 ./two 1 : ./two 1
  (Both processes print once without interruption)

Test 2: Processes interrupted mid-execution
  ./schedule 500 ./two 3 : ./two 3
  (Each process prints 3 times (3 seconds), but quantum is 500ms,
   so they get interrupted and resume on next round)

KNOWN LIMITATIONS:
None known.

DESIGN NOTES:
- The scheduler uses pause() rather than busy-waiting for signals
- Resource allocation is dynamic - processes are allocated from the heap
- The round-robin order is strictly maintained - processes rotate in their original order
- Signal handlers use volatile flags to communicate with the main loop
