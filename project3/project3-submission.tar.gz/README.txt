CPE 453 - Project 3 (Virtual Memory Simulator)

Names:
- TODO: Your Name Here
- TODO: Partner Name Here (if any)

Files:
- memSim            : executable wrapper script (Python)
- memSim.py         : main simulator driver
- tlb.py            : 16-entry FIFO TLB
- page_table.py     : page table with loaded bit
- physical_memory.py: physical memory frames
- backing_store.py  : backing store reader for BACKING_STORE.bin
- page_replacement.py: FIFO/LRU/OPT page replacement strategies
- report.txt        : short design report
- Makefile          : helper targets (optional for Python)

How to run:
- Requires Python 3.
- BACKING_STORE.bin must be present in the same directory when running.

Usage:
  ./memSim <reference-sequence-file.txt> [FRAMES] [PRA]

Arguments:
- reference-sequence-file.txt: one logical address per line (integer)
- FRAMES: number of frames (1..256). Default: 256
- PRA: fifo | lru | opt. Default: fifo

Example:
  ./memSim addresses.txt 256 fifo
  ./memSim addresses.txt 64 lru
  ./memSim addresses.txt 32 opt

Notes / shortcomings:
- TLB size is fixed at 16 entries (per assignment spec).
- LRU is implemented as a straightforward timestamp-based least-recently-used on frames.
- OPT uses full lookahead over the provided reference sequence.
